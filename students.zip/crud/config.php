<?php

$conn = mysqli_connect("localhost","root","","crud") or die("Connection Failed");

?>
